package com.example.authentication.navigation

import androidx.compose.runtime.Composable
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.navArgument
import androidx.navigation.NavType
import com.example.feature_meals.presentation.MealListScreen
import com.example.feature_meals.presentation.MealDetailScreen

@Composable
fun SetupNavGraph(navController: NavHostController) {
    NavHost(
        navController = navController,
        startDestination = "meal_list"
    ) {
        // 1. Meal List Route
        composable(route = "meal_list") {
            MealListScreen(
                onMealClick = { id ->
                    navController.navigate("meal_detail/$id")
                }
            )
        }

        // 2. Meal Detail Route
        composable(
            route = "meal_detail/{mealId}",
            arguments = listOf(
                navArgument("mealId") { type = NavType.StringType }
            )
        ) { backStackEntry ->
            val mealId = backStackEntry.arguments?.getString("mealId")
            MealDetailScreen(
                mealId = mealId,
                onBack = { navController.popBackStack() }
            )
        }
    }
}